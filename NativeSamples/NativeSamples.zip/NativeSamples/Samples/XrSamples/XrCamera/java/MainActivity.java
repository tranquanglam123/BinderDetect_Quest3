// Copyright (c) Facebook Technologies, LLC and its affiliates. All Rights reserved.
package com.oculus.sdk.xrcamera;

public class MainActivity extends android.app.NativeActivity {}
